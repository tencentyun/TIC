//
//  TEduBoard.h
//  TEduBoard
//
//  Created by kennethmiao on 2019/4/2.
//  Copyright © 2019年 kennethmiao. All rights reserved.
//

#import <Foundation/Foundation.h>
#if TARGET_OS_IPHONE
#import <TEduBoard/TEduBoardDef.h>
#import <TEduBoard/TEduBoardController.h>
#else
#import <TEduBoard_Mac/TEduBoardDef.h>
#import <TEduBoard_Mac/TEduBoardController.h>
#endif

